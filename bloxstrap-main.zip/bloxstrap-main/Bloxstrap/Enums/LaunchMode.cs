﻿namespace Bloxstrap.Enums
{
    public enum LaunchMode
    {
        None,
        Player,
        Studio,
        StudioAuth
    }
}
