﻿namespace Bloxstrap.Enums
{
    public enum GenericTriState
    {
        Successful,
        Failed,
        Unknown
    }
}
